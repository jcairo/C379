#!/bin/bash
STRING="Starting programs."
echo $STRING
./test2 &
./test2 &
./test2 &
./a.out &
./a.out &
./a.out &
./hellohowareyoumynameisjim &
./hellohowareyoumynameisjim &
./hellohowareyoumynameisjim &
./hellohowareyoumynameisjim &